--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Debian 16.1-1.pgdg120+1)
-- Dumped by pg_dump version 16.1 (Debian 16.1-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: covid; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA covid;


ALTER SCHEMA covid OWNER TO postgres;

--
-- Name: geo_info; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA geo_info;


ALTER SCHEMA geo_info OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daily_statistics; Type: TABLE; Schema: covid; Owner: postgres
--

CREATE TABLE covid.daily_statistics (
    id integer NOT NULL,
    country_id integer NOT NULL,
    region_id integer,
    observed_date date NOT NULL,
    confirmed integer,
    deaths integer
);


ALTER TABLE covid.daily_statistics OWNER TO postgres;

--
-- Name: COLUMN daily_statistics.country_id; Type: COMMENT; Schema: covid; Owner: postgres
--

COMMENT ON COLUMN covid.daily_statistics.country_id IS 'ID страны';


--
-- Name: COLUMN daily_statistics.region_id; Type: COMMENT; Schema: covid; Owner: postgres
--

COMMENT ON COLUMN covid.daily_statistics.region_id IS 'ID региона в стране';


--
-- Name: COLUMN daily_statistics.observed_date; Type: COMMENT; Schema: covid; Owner: postgres
--

COMMENT ON COLUMN covid.daily_statistics.observed_date IS 'Дата наблюдения';


--
-- Name: COLUMN daily_statistics.confirmed; Type: COMMENT; Schema: covid; Owner: postgres
--

COMMENT ON COLUMN covid.daily_statistics.confirmed IS 'Кол-во подтвержденных случаев';


--
-- Name: COLUMN daily_statistics.deaths; Type: COMMENT; Schema: covid; Owner: postgres
--

COMMENT ON COLUMN covid.daily_statistics.deaths IS 'Кол-во смертей';


--
-- Name: countries; Type: TABLE; Schema: geo_info; Owner: postgres
--

CREATE TABLE geo_info.countries (
    id integer NOT NULL,
    iso2 character varying(2) NOT NULL,
    iso3 character varying(3) NOT NULL,
    name character varying(50) NOT NULL,
    population integer,
    density double precision,
    prop_population_65 double precision,
    prop_population_f double precision
);


ALTER TABLE geo_info.countries OWNER TO postgres;

--
-- Name: COLUMN countries.iso2; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.countries.iso2 IS 'Двухбуквенное международное обозначение';


--
-- Name: COLUMN countries.iso3; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.countries.iso3 IS 'Трехбуквенное международное обозначение';


--
-- Name: COLUMN countries.name; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.countries.name IS 'Название страны';


--
-- Name: COLUMN countries.population; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.countries.population IS 'Население страны';


--
-- Name: COLUMN countries.density; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.countries.density IS 'Плотность населения';


--
-- Name: COLUMN countries.prop_population_65; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.countries.prop_population_65 IS 'Доля населения старше 65';


--
-- Name: COLUMN countries.prop_population_f; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.countries.prop_population_f IS 'Доля женского населения';


--
-- Name: disease_statistics; Type: TABLE; Schema: geo_info; Owner: postgres
--

CREATE TABLE geo_info.disease_statistics (
    country_id integer NOT NULL,
    diabetes double precision,
    obesity double precision,
    smoking double precision,
    copd double precision,
    copd_f double precision,
    copd_m double precision,
    cvd double precision,
    cvd_f double precision,
    cvd_m double precision,
    hiv double precision,
    hiv_f double precision,
    hiv_m double precision,
    hypertension double precision,
    hypertension_f double precision,
    hypertension_m double precision
);


ALTER TABLE geo_info.disease_statistics OWNER TO postgres;

--
-- Name: COLUMN disease_statistics.country_id; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.country_id IS 'ID страны';


--
-- Name: COLUMN disease_statistics.diabetes; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.diabetes IS 'Процент распространенности с поправкой на возраст среди взрослых (>=18 лет) с диагностированным диабетом';


--
-- Name: COLUMN disease_statistics.obesity; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.obesity IS 'Процент взрослых, страдающих ожирением (индекс массы тела 30+)';


--
-- Name: COLUMN disease_statistics.smoking; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.smoking IS 'Процент распространенности курения среди взрослых, скорректированный по возрасту';


--
-- Name: COLUMN disease_statistics.copd; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.copd IS 'Стандартизированный по возрасту процент распространенности хронической обструктивной болезни легких по полу (всего)';


--
-- Name: COLUMN disease_statistics.copd_f; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.copd_f IS 'Стандартизированный по возрасту процент распространенности хронической обструктивной болезни легких по полу (женщины)';


--
-- Name: COLUMN disease_statistics.copd_m; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.copd_m IS 'Стандартизированный по возрасту процент распространенности хронической обструктивной болезни легких по полу (мужчины)';


--
-- Name: COLUMN disease_statistics.cvd; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.cvd IS 'Стандартизированный по возрасту процент распространенности сердечно-сосудистых заболеваний по полу (всего)';


--
-- Name: COLUMN disease_statistics.cvd_f; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.cvd_f IS 'Стандартизированный по возрасту процент распространенности сердечно-сосудистых заболеваний по полу (женщины)';


--
-- Name: COLUMN disease_statistics.cvd_m; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.cvd_m IS 'Стандартизированный по возрасту процент распространенности сердечно-сосудистых заболеваний по полу (мужчины)';


--
-- Name: COLUMN disease_statistics.hiv; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.hiv IS 'Стандартизированный по возрасту процент распространенности ВИЧ/СПИДа по полу (всего)';


--
-- Name: COLUMN disease_statistics.hiv_f; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.hiv_f IS 'Стандартизированный по возрасту процент распространенности ВИЧ/СПИДа по полу (женщины)';


--
-- Name: COLUMN disease_statistics.hiv_m; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.hiv_m IS 'Стандартизированный по возрасту процент распространенности ВИЧ/СПИДа по полу (мужчины)';


--
-- Name: COLUMN disease_statistics.hypertension; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.hypertension IS 'Процент взрослых с гипертонией по полу (всего)';


--
-- Name: COLUMN disease_statistics.hypertension_f; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.hypertension_f IS 'Процент взрослых с гипертонией по полу (женщины)';


--
-- Name: COLUMN disease_statistics.hypertension_m; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.disease_statistics.hypertension_m IS 'Процент взрослых с гипертонией по полу (мужчины)';


--
-- Name: regions; Type: TABLE; Schema: geo_info; Owner: postgres
--

CREATE TABLE geo_info.regions (
    id integer NOT NULL,
    country_id integer NOT NULL,
    name character varying(100) NOT NULL,
    population integer,
    density double precision,
    prop_population_65 double precision,
    prop_population_f double precision
);


ALTER TABLE geo_info.regions OWNER TO postgres;

--
-- Name: COLUMN regions.country_id; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.regions.country_id IS 'ID страны, в котором находится регион';


--
-- Name: COLUMN regions.name; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.regions.name IS 'Название региона';


--
-- Name: COLUMN regions.population; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.regions.population IS 'Население региона';


--
-- Name: COLUMN regions.density; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.regions.density IS 'Плотность населения';


--
-- Name: COLUMN regions.prop_population_65; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.regions.prop_population_65 IS 'Доля населения старше 65';


--
-- Name: COLUMN regions.prop_population_f; Type: COMMENT; Schema: geo_info; Owner: postgres
--

COMMENT ON COLUMN geo_info.regions.prop_population_f IS 'Доля женского населения';


--
-- Data for Name: daily_statistics; Type: TABLE DATA; Schema: covid; Owner: postgres
--

COPY covid.daily_statistics (id, country_id, region_id, observed_date, confirmed, deaths) FROM stdin;
\.
COPY covid.daily_statistics (id, country_id, region_id, observed_date, confirmed, deaths) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: countries; Type: TABLE DATA; Schema: geo_info; Owner: postgres
--

COPY geo_info.countries (id, iso2, iso3, name, population, density, prop_population_65, prop_population_f) FROM stdin;
\.
COPY geo_info.countries (id, iso2, iso3, name, population, density, prop_population_65, prop_population_f) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: disease_statistics; Type: TABLE DATA; Schema: geo_info; Owner: postgres
--

COPY geo_info.disease_statistics (country_id, diabetes, obesity, smoking, copd, copd_f, copd_m, cvd, cvd_f, cvd_m, hiv, hiv_f, hiv_m, hypertension, hypertension_f, hypertension_m) FROM stdin;
\.
COPY geo_info.disease_statistics (country_id, diabetes, obesity, smoking, copd, copd_f, copd_m, cvd, cvd_f, cvd_m, hiv, hiv_f, hiv_m, hypertension, hypertension_f, hypertension_m) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: regions; Type: TABLE DATA; Schema: geo_info; Owner: postgres
--

COPY geo_info.regions (id, country_id, name, population, density, prop_population_65, prop_population_f) FROM stdin;
\.
COPY geo_info.regions (id, country_id, name, population, density, prop_population_65, prop_population_f) FROM '$$PATH$$/3379.dat';

--
-- Name: daily_statistics daily_statistics_pkey; Type: CONSTRAINT; Schema: covid; Owner: postgres
--

ALTER TABLE ONLY covid.daily_statistics
    ADD CONSTRAINT daily_statistics_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: geo_info; Owner: postgres
--

ALTER TABLE ONLY geo_info.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: geo_info; Owner: postgres
--

ALTER TABLE ONLY geo_info.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: daily_statistics fk_daily_statistics_country_id; Type: FK CONSTRAINT; Schema: covid; Owner: postgres
--

ALTER TABLE ONLY covid.daily_statistics
    ADD CONSTRAINT fk_daily_statistics_country_id FOREIGN KEY (country_id) REFERENCES geo_info.countries(id);


--
-- Name: daily_statistics fk_daily_statistics_region_id; Type: FK CONSTRAINT; Schema: covid; Owner: postgres
--

ALTER TABLE ONLY covid.daily_statistics
    ADD CONSTRAINT fk_daily_statistics_region_id FOREIGN KEY (region_id) REFERENCES geo_info.regions(id);


--
-- Name: disease_statistics fk_disease_statistics_country_id; Type: FK CONSTRAINT; Schema: geo_info; Owner: postgres
--

ALTER TABLE ONLY geo_info.disease_statistics
    ADD CONSTRAINT fk_disease_statistics_country_id FOREIGN KEY (country_id) REFERENCES geo_info.countries(id);


--
-- Name: regions fk_region_county_id; Type: FK CONSTRAINT; Schema: geo_info; Owner: postgres
--

ALTER TABLE ONLY geo_info.regions
    ADD CONSTRAINT fk_region_county_id FOREIGN KEY (country_id) REFERENCES geo_info.countries(id);


--
-- PostgreSQL database dump complete
--

